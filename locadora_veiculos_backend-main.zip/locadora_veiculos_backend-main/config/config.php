<?php
    // arquivo de configuração com as constantes do sistema
    define('ARQUIVO_JSON', __DIR__ . '/../data/veiculos.json');
    define('ARQUIVO_USUARIOS', __DIR__ . '/../data/usuarios.json');
    define('DIARIA_CARRO', 100.00);
    define('DIARIA_MOTO', 50.00);
?>